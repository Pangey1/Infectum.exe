@echo off
C:\mingw32\bin\windres.exe resource.rc -o resource.o
C:\mingw32\bin\g++.exe Main.cpp resource.o -o Infectum-safety.exe -mwindows -lgdi32 -lwinmm -static -static-libgcc -static-libstdc++
pause
